#ifndef ADMIN_H
#define ADMIN_H

void admin_menu(int connFD);
void admin_add_manager();
void admin_add_employee();
void admin_logout(int connFD);

#endif
