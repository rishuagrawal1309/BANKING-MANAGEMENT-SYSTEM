#ifndef MANAGER_H
#define MANAGER_H
void manager_menu(int connFD);
#endif
