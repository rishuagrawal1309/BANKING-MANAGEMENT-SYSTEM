#ifndef CUSTOMER_H
#define CUSTOMER_H
void customer_menu(int connFD);
#endif
